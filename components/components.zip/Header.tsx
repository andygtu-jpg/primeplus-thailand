export default function Header() {
  return (
    <header className="fixed top-0 left-0 z-50 w-full border-b border-zinc-800 bg-black/80 backdrop-blur-lg">
      <div className="container flex h-20 items-center justify-between">

        {/* Logo */}
        <a href="#home" className="flex items-center gap-3">
          <img
            src="/logo.png"
            alt="Prime Plus"
            className="h-12 w-auto"
          />

          <div>
            <h1 className="text-xl font-bold tracking-wider text-red-500">
              PRIME PLUS
            </h1>

            <p className="text-xs text-zinc-400">
              Premium Supplement
            </p>
          </div>
        </a>

        {/* Menu */}
        <nav className="hidden items-center gap-8 text-sm font-medium md:flex">

          <a
            href="#home"
            className="text-zinc-300 transition hover:text-red-500"
          >
            Home
          </a>

          <a
            href="#benefits"
            className="text-zinc-300 transition hover:text-red-500"
          >
            Benefits
          </a>

          <a
            href="#ingredients"
            className="text-zinc-300 transition hover:text-red-500"
          >
            Ingredients
          </a>

          <a
            href="#reviews"
            className="text-zinc-300 transition hover:text-red-500"
          >
            Reviews
          </a>

          <a
            href="#order"
            className="text-zinc-300 transition hover:text-red-500"
          >
            Order
          </a>

          <a
            href="#contact"
            className="text-zinc-300 transition hover:text-red-500"
          >
            Contact
          </a>

        </nav>

        {/* Button */}
        <a
          href="#order"
          className="rounded-xl bg-red-600 px-6 py-3 font-semibold text-white transition hover:bg-red-700"
        >
          Order Now
        </a>

      </div>
    </header>
  );
}