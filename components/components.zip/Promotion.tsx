export default function Promotion() {
  return (
    <section
      id="order"
      style={{
        background: "linear-gradient(135deg,#d40000,#7a0000)",
        color: "white",
        padding: "120px 20px",
        textAlign: "center",
      }}
    >
      <p
        style={{
          color: "#ffd966",
          letterSpacing: "3px",
          textTransform: "uppercase",
          fontWeight: "bold",
          marginBottom: "10px",
        }}
      >
        Special Promotion
      </p>

      <h2
        style={{
          fontSize: "56px",
          marginBottom: "20px",
        }}
      >
        โปรโมชั่นพิเศษ
      </h2>

      <div
        style={{
          display: "flex",
          justifyContent: "center",
          gap: "30px",
          flexWrap: "wrap",
          marginTop: "50px",
        }}
      >
        <div
          style={{
            background: "rgba(255,255,255,.1)",
            padding: "35px",
            borderRadius: "20px",
            width: "260px",
            backdropFilter: "blur(12px)",
          }}
        >
          <h3>ราคาปกติ</h3>

          <h1
            style={{
              fontSize: "64px",
              color: "white",
            }}
          >
            400
          </h1>

          <p>บาท / กล่อง</p>
        </div>

        <div
          style={{
            background: "#111",
            padding: "35px",
            borderRadius: "20px",
            width: "260px",
            boxShadow: "0 0 40px rgba(255,0,0,.5)",
          }}
        >
          <h3>ซื้อ 2 กล่อง</h3>

          <h1
            style={{
              fontSize: "64px",
              color: "#ffe600",
            }}
          >
            700
          </h1>

          <p>บาท</p>

          <p
            style={{
              color: "#00ff66",
            }}
          >
            ✔ ประหยัดทันที 100 บาท
          </p>
        </div>
      </div>

      <button
        style={{
          marginTop: "70px",
          background: "#111",
          color: "white",
          border: "2px solid white",
          padding: "20px 60px",
          fontSize: "22px",
          borderRadius: "12px",
          cursor: "pointer",
          transition: ".3s",
        }}
      >
        สั่งซื้อทันที
      </button>
    </section>
  );
}