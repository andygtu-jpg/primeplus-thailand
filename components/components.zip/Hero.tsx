export default function Hero() {
  return (
    <section
      id="home"
      className="bg-gradient-to-b from-black via-zinc-950 to-black pt-32 pb-24"
    >
      <div className="container grid items-center gap-16 lg:grid-cols-2">

        {/* Product Image */}
        <div className="flex justify-center">
          <img
            src="/primeplus-box.png"
            alt="Prime Plus"
            className="w-80 drop-shadow-[0_0_40px_rgba(255,0,0,0.35)] transition duration-500 hover:scale-105"
          />
        </div>

        {/* Content */}
        <div>

          <span className="rounded-full border border-red-500 px-4 py-2 text-sm text-red-400">
            PREMIUM MEN'S SUPPLEMENT
          </span>

          <h1 className="mt-6 text-5xl font-extrabold leading-tight text-white lg:text-7xl">
            PRIME
            <span className="text-red-500"> PLUS</span>
          </h1>

          <p className="mt-6 max-w-xl text-lg leading-8 text-zinc-300">
            ผลิตภัณฑ์เสริมอาหารสำหรับผู้ชาย
            ผลิตภายใต้มาตรฐานการผลิตที่เกี่ยวข้อง
            พร้อมบรรจุภัณฑ์คุณภาพและการจัดส่งทั่วประเทศ
          </p>

          <div className="mt-8 space-y-2">
            <h2 className="text-4xl font-bold text-white">
              400 บาท / กล่อง
            </h2>

            <p className="text-2xl font-semibold text-green-400">
              ซื้อ 2 กล่อง เพียง 700 บาท
            </p>
          </div>

          <div className="mt-10 flex flex-wrap gap-4">

            <a
              href="#order"
              className="rounded-xl bg-red-600 px-8 py-4 font-bold text-white transition hover:bg-red-700"
            >
              สั่งซื้อทันที
            </a>

            <a
              href="https://line.me/R/ti/p/@563dlggh"
              target="_blank"
              rel="noopener noreferrer"
              className="rounded-xl border border-green-500 px-8 py-4 font-bold text-green-400 transition hover:bg-green-500 hover:text-white"
            >
              LINE Official
            </a>

          </div>

        </div>

      </div>
    </section>
  );
}