const features = [
  {
    icon: "🌿",
    title: "ส่วนผสมคุณภาพ",
    desc: "คัดสรรวัตถุดิบอย่างพิถีพิถันตามมาตรฐานการผลิต",
  },
  {
    icon: "🏭",
    title: "มาตรฐานการผลิต",
    desc: "ผลิตในโรงงานที่ได้รับมาตรฐานที่เกี่ยวข้อง",
  },
  {
    icon: "💊",
    title: "รับประทานง่าย",
    desc: "สะดวกต่อการรับประทานตามคำแนะนำบนฉลาก",
  },
  {
    icon: "📦",
    title: "บรรจุภัณฑ์พรีเมียม",
    desc: "ออกแบบให้พกพาสะดวกและดูทันสมัย",
  },
  {
    icon: "🚚",
    title: "จัดส่งทั่วประเทศ",
    desc: "แพ็กสินค้าอย่างดี พร้อมจัดส่งรวดเร็ว",
  },
  {
    icon: "⭐",
    title: "บริการหลังการขาย",
    desc: "ติดต่อสอบถามและรับคำแนะนำผ่าน LINE Official",
  },
];

export default function Features() {
  return (
    <section id="benefits" className="bg-zinc-950 py-24">
      <div className="container">
        <h2 className="title">ทำไมต้อง PRIME PLUS</h2>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {features.map((item) => (
            <div
              key={item.title}
              className="card p-8 text-center"
            >
              <div className="mb-5 text-5xl">
                {item.icon}
              </div>

              <h3 className="mb-3 text-2xl font-bold text-white">
                {item.title}
              </h3>

              <p className="leading-7 text-zinc-400">
                {item.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}