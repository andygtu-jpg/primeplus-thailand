"use client";

import { useState } from "react";

export default function OrderForm() {
  const [qty, setQty] = useState(1);

  const price = qty >= 2 ? 700 : 400;

  return (
    <section
      id="order-form"
      style={{
        background: "#111",
        color: "white",
        padding: "100px 20px",
      }}
    >
      <div
        style={{
          maxWidth: "700px",
          margin: "auto",
          background: "#1b1b1b",
          borderRadius: "20px",
          padding: "40px",
          boxShadow: "0 0 30px rgba(255,0,0,.25)",
        }}
      >
        <h2
          style={{
            textAlign: "center",
            color: "#ff4040",
            fontSize: "42px",
            marginBottom: "40px",
          }}
        >
          สั่งซื้อสินค้า
        </h2>

        <input
          placeholder="ชื่อ - นามสกุล"
          style={inputStyle}
        />

        <input
          placeholder="เบอร์โทรศัพท์"
          style={inputStyle}
        />

        <textarea
          placeholder="ที่อยู่จัดส่ง"
          rows={4}
          style={{
            ...inputStyle,
            resize: "none",
          }}
        />

        <select
          value={qty}
          onChange={(e) => setQty(Number(e.target.value))}
          style={inputStyle}
        >
          <option value={1}>1 กล่อง</option>
          <option value={2}>2 กล่อง (โปรโมชั่น)</option>
          <option value={3}>3 กล่อง</option>
          <option value={4}>4 กล่อง</option>
          <option value={5}>5 กล่อง</option>
        </select>

        <div
          style={{
            marginTop: "30px",
            padding: "25px",
            background: "#222",
            borderRadius: "12px",
            textAlign: "center",
          }}
        >
          <p style={{ color: "#bbb" }}>ยอดชำระทั้งหมด</p>

          <h1
            style={{
              color: "#ff4040",
              fontSize: "56px",
            }}
          >
            {price} บาท
          </h1>
        </div>

        <button
          style={{
            width: "100%",
            marginTop: "35px",
            padding: "18px",
            background: "#ff4040",
            color: "white",
            border: "none",
            borderRadius: "12px",
            fontSize: "20px",
            cursor: "pointer",
            fontWeight: "bold",
          }}
        >
          ยืนยันการสั่งซื้อ
        </button>
      </div>
    </section>
  );
}

const inputStyle = {
  width: "100%",
  padding: "16px",
  marginBottom: "20px",
  background: "#222",
  border: "1px solid #444",
  borderRadius: "10px",
  color: "white",
  fontSize: "16px",
} as const;